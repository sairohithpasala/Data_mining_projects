Student Details-

Team Names and ID:

Student Name and ID: Sai Rohith Pasala; 1001873156

Student Name and ID: Sri Naga Venkata Pavan Kalyan Sirigibattula; 1001886149

Student Name and ID: Rutvik Naga Sai Dondapati; 1001879177

       Dataset                                           Programming Language              
Federal Emergencies Database dataset          -             Python
IMDB Movie Review Database dataset            -            R- Rstudio / R environment variable integrated to anaconda navigator
Statewise covid19 deatils Database dataset    -               Weka


1.All the dataset files should be in their respective programming folder inorder to execute

2.In order to execute python just open the ipynb file

3.In order to execute R , Install R environment variable in anaconda navigator and then
       open adn execute .ipynb file in R imdb movie folder
                          OR

          open the .ipynb file directly from R folder and click on option "Continue without kernel"

4. All the Weka related task have been mentioned in report(as it is visualising tool) and 
     opening statewisedetails.arff to see the visualised data in weka explorer

5. All the presentation for the projects have saved to presentations folder